
public enum Dimension {
	X,
	Y
}
