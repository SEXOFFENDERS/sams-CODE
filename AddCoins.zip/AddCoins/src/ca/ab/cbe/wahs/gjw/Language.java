package ca.ab.cbe.wahs.gjw;

public enum Language {
    ENGLISH, 
    FRENCH
}