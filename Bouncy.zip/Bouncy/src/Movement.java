
public class Movement {
		protected double newVelocity = 0;
		protected double newLocaton = 0;
		protected boolean didCollide = false;		
	}
